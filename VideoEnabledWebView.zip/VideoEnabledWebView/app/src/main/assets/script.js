

$.getJSON('https://raw.githubusercontent.com/firzi15/stb21/main/event', function (data) {
  $.each(data.group, function(i, f) {
    $('#acara').append('<f tabindex="-1"> ' + f.ttl + ' </f>');
  });
 });



$.getJSON('https://raw.githubusercontent.com/firzi15/stb21/main/event', function (data) {
  $.each(data.items, function(i, f) {
    $('#event').append('<li class="scroll-nav"><a href="' + f.url + '"><img tabindex="1" class="squareBig" src="' + f.src + '" download="' + f.ttl + '"></img></a></li>');
  });
 });

