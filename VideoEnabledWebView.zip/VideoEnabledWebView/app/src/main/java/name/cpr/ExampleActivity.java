package name.cpr;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import cpr.name.videoenabledwebview.R;
import android.view.*;
import android.content.pm.*;
import android.webkit.*;
import android.app.*;
import android.content.*;
import android.support.v4.app.*;
import android.text.*;
import android.widget.*;
import android.support.v7.internal.widget.*;
import android.app.AlertDialog.*;
import java.net.*;
import android.net.*;
import android.net.http.*;
import android.graphics.Bitmap.*;
import android.graphics.*;
import android.os.*;



public class ExampleActivity extends ActionBarActivity
{
	
	
    private VideoEnabledWebView webView;
    private VideoEnabledWebChromeClient webChromeClient;
    private ProgressBar spinner;
	
	WebView WebView;
	ProgressBar ProgressBar;
	Toolbar toolbar;
	
	int i=0;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example);
		
		webView=findViewById(R.id.webView);
        ProgressBar=findViewById(R.id.ProgressBar);
        
		spinner = (ProgressBar)findViewById(R.id.ProgressBar);
		webView.setWebViewClient(new CustomWebViewClient());

		final int oneMin = 1 * 60 * 1000; // 1 minute in milli seconds

        /** CountDownTimer starts with 1 minutes and every onTick is 1 second */
        new CountDownTimer(oneMin, 1000) {
            public void onTick(long millisUntilFinished) {

                //forward progress
                long finishedSeconds = oneMin - millisUntilFinished;
                int total = (int) (((float)finishedSeconds / (float)oneMin) * 100.0);
                spinner.setProgress(total);

//                //backward progress
//                int total = (int) (((float) millisUntilFinished / (float) oneMin) * 100.0);
//                progressBar.setProgress(total);

            }

            public void onFinish() {
                // DO something when 1 minute is up
            }
        } .start();
			
		// Mixed content
		webView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
		
		// Orientation landscape only
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
	
		// Hide status bar
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		// Hide title bar
		getSupportActionBar().hide();
		
        // Save the web view
        webView = (VideoEnabledWebView)findViewById(R.id.webView);
		
		//Autoplay media
		webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
	
		//High render video
		webView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
		
		//Utilities
		WebSettings webSettings = webView.getSettings();
		webView.setBackgroundColor(getColor(android.R.color.transparent));
		webView.getSettings().setAllowFileAccess( true );
		webView.getSettings().setAppCacheEnabled( true );
		webView.getSettings().setJavaScriptEnabled( true );
	    webView.getSettings().setCacheMode( WebSettings.LOAD_DEFAULT );
		webView.setFocusableInTouchMode(true);
		webView.setFocusable(true);
		webView.setKeepScreenOn(true);
		webView.getSettings().setAppCachePath( getApplicationContext().getCacheDir().getAbsolutePath() );
		webView.getSettings().setLoadsImagesAutomatically(true);
		
		
		
		
		// Wide view
        webSettings.setUseWideViewPort(true);
		
		// Database enabled
		webSettings.setDatabaseEnabled(true);
		
		// Dom storage enabled
		webView.getSettings().setDomStorageEnabled(true);
		
		// Hide scroll
		webView.setVerticalScrollBarEnabled(false);
		webView.setHorizontalScrollBarEnabled(false);
		
		// Multiple windows
		webSettings.setSupportMultipleWindows(true);
	
        // Initialize the VideoEnabledWebChromeClient and set event handlers
        View nonVideoLayout = findViewById(R.id.nonVideoLayout); // Your own view, read class comments
        ViewGroup videoLayout = (ViewGroup)findViewById(R.id.videoLayout); // Your own view, read class comments
        //noinspection all
        View loadingView = getLayoutInflater().inflate(R.layout.view_loading_video, null); // Your own view, read class comments
        webChromeClient = new VideoEnabledWebChromeClient(nonVideoLayout, videoLayout, loadingView, webView) // See all available constructors...
        {
            // Subscribe to standard events, such as onProgressChanged()...
			
			
			
            @Override
            public void onProgressChanged(WebView view, int Progress)
            {
				super.onProgressChanged(view, Progress);
				ProgressBar.setProgress(Progress);
				if (Progress == 100) {

					// HIDE VIEW
					
					}
				super.onProgressChanged(view, Progress);
				
            }
        };
        webChromeClient.setOnToggledFullscreen(new VideoEnabledWebChromeClient.ToggledFullscreenCallback()
        {
            @Override
            public void toggledFullscreen(boolean fullscreen)
            {
                // Your code to handle the full-screen change, for example showing and hiding the title bar. Example:
                if (fullscreen)
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags |= WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE);
                    }
                }
                else
                {
                    WindowManager.LayoutParams attrs = getWindow().getAttributes();
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_FULLSCREEN;
                    attrs.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    getWindow().setAttributes(attrs);
                    if (android.os.Build.VERSION.SDK_INT >= 14)
                    {
                        //noinspection all
                        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
                    }
                }

            }
        });
		
		
		
			
		if (!DetectConnection.checkInternetConnection(this)) {
			
			
			final AlertDialog.Builder builder = new AlertDialog.Builder(ExampleActivity .this);
			builder.setCancelable(false);
			builder.setTitle("No internet connection");
			builder.setMessage("You need internet access to use this application");
            
			builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialogInterface, int i) {
						finish();
					}
				}); 

		

			// Create the alert dialog using alert dialog builder
			AlertDialog dialog = builder.create();

			// Finally, display the dialog when user press back button
			dialog.show();
			
		} else {
		
        webView.setWebChromeClient(webChromeClient);
		
			
        // Call private class InsideWebViewClient
        webView.setWebViewClient(new InsideWebViewClient());
        
		//Allow cache
		webView.getSettings().setAppCacheEnabled(true);
		
		//Plugin
		webView.getSettings().setPluginState(WebSettings.PluginState.ON); 
		
        // Navigate anywhere you want, but consider that this classes have only been tested on YouTube's mobile site
			webView.loadUrl("file:///android_asset/index.html");
		
	
		//Allow javascript
		webView.getSettings().setJavaScriptEnabled(true);
		
		//Software
		webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
		
		//Hardware
		webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
		
		
		

     }
	 
	}


	
	public void onReceivedError(WebView webview, int errorCode, String description, String failingUrl) {
		webview.post(new Runnable() {
			
			
			
				@Override
				public void run() {				
					webView.stopLoading();
					final AlertDialog.Builder builder = new AlertDialog.Builder(ExampleActivity .this);
					builder.setCancelable(false);
					builder.setTitle("No internet detection");
					builder.setMessage("You need internet access to use this application");

					builder.setPositiveButton("Exit", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialogInterface, int i) {
								finish();
							}
						}); 



					// Create the alert dialog using alert dialog builder
					AlertDialog dialog = builder.create();

					// Finally, display the dialog when user press back button
					dialog.show();

				}
				
			});
	};
	
	// This allows for a splash screen 
// (and hide elements once the page loads)
	private class CustomWebViewClient extends WebViewClient {

		@Override
		public void onPageStarted(WebView webview, String url, Bitmap favicon) {
			webview.setVisibility(webview.INVISIBLE);
		}

		@Override
		public void onPageFinished(WebView view, String url) {

			

			view.setVisibility(WebView.VISIBLE);
			super.onPageFinished(view, url);

		}
	}
	
	
    private class InsideWebViewClient extends WebViewClient {
		
		public void onReceivedError(WebView webview, WebResourceRequest request, WebResourceError error) {			
		super.onReceivedError(webview, request, error);			
		}
		
		
        @Override	
        // Force links to be opened inside WebView and not in Default Browser
        // Thanks http://stackoverflow.com/a/33681975/1815624
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
			if (url.endsWith(".m3u8") || url.endsWith(".ts") || url.endsWith(".mpd") || url.endsWith(".mp4"))
			{
				try {
				Intent intent = new Intent(Intent.ACTION_VIEW); 
                intent.setDataAndType(Uri.parse(url), "video/*");
				intent.setPackage("com.genuine.leone");
                view.getContext().startActivity(intent);   
                return true; // to tell the WebView that it should not load the URL because you handled it by yourself
			}
			
				catch (ActivityNotFoundException e) {
// Player is not installed, you may want to open the play store link
					Uri uri = Uri.parse(url);
					startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.genuine.leone")));
					return true;
				}
				}
			//webView.loadUrl(url); vh remove this. You need to return true or false to tell the WebView if it should load the url, or not
			return false; //to tell WebView that you didn't handle the URL, and it should load it.
		}
    }
	
	
	
    
	@Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            // If web view have back history, then go to the web view back history
            webView.goBack();
        } else {
            // Ask the user to exit the app or stay in here
            exitApp();
        }
    }


	public void exitApp() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(ExampleActivity .this);
		
        builder.setTitle("Please confirm");
        builder.setMessage("Do you want to exit the app?");
        builder.setCancelable(true);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					finish();
				}
			});

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					dialogInterface.dismiss();
				}
			});

        // Create the alert dialog using alert dialog builder
        AlertDialog dialog = builder.create();

        // Finally, display the dialog when user press back button
        dialog.show();
    }
	
}
